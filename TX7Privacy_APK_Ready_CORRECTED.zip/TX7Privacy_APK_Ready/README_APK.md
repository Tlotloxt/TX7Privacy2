# TX7 Privacy — APK-ready Android project

This ZIP is configured for GitHub Actions APK builds.

## Versions
- Gradle: **8.9**
- Android Gradle Plugin: **8.7.3**
- Kotlin: **2.0.21**
- Java/JDK: **17**
- Kotlin JVM toolchain: **17**
- Compile/Target SDK: **35**
- Application ID: `com.tx7.privacy`

## Build with GitHub Actions
1. Extract this ZIP.
2. Upload/replace the project files in your GitHub repository.
3. Open the repository's **Actions** tab.
4. Select **Build TX7 Privacy APK**.
5. Tap **Run workflow**.
6. When the workflow finishes, open the workflow run and download the **TX7Privacy-debug-apk** artifact.
7. Extract the artifact and install `app-debug.apk` on your Android phone.

The workflow installs and uses Gradle 8.9 directly, so no manual Gradle edits are required.

## Project preserved
Your existing TX7 Privacy application package, dashboard UI, navigation tabs, overlay permission button, privacy strength, stealth mode, and current source files are preserved.

## Important
This project builds the current TX7 Privacy dashboard APK. The cross-app privacy overlay service itself is not implemented yet; the existing button opens Android's official "Display over other apps" permission screen.
