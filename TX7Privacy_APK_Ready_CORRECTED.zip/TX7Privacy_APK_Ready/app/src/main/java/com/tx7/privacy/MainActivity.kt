package com.tx7.privacy

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF07070A)
private val Card = Color(0xFF101116)
private val Purple = Color(0xFF9B4DFF)
private val Bright = Color(0xFFB66CFF)
private val Muted = Color(0xFF9A96A3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg,
                    surface = Card,
                    primary = Purple
                )
            ) {
                TX7App(
                    onOverlayPermission = {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun TX7App(onOverlayPermission: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var enabled by remember { mutableStateOf(false) }
    var strength by remember { mutableFloatStateOf(.8f) }
    var stealth by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Dashboard(enabled, { enabled = !enabled }, strength, { strength = it }, stealth, { stealth = it }, onOverlayPermission)
                    1 -> SimplePage("MODES", "Standard • High Privacy • Maximum • Stealth")
                    2 -> SimplePage("AUTO PRIVACY", "Choose which apps automatically enable privacy")
                    3 -> SimplePage("HISTORY", "Privacy sessions and usage statistics")
                    4 -> SimplePage("SETTINGS", "Overlay permission • Appearance • Notifications")
                }
            }
            NavigationBar(containerColor = Color(0xFF09090D)) {
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.Shield, Icons.Default.AutoMode, Icons.Default.History, Icons.Default.Settings)
                val names = listOf("Dashboard", "Modes", "Auto", "History", "Settings")
                icons.forEachIndexed { i, icon ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, null) },
                        label = { Text(names[i], fontSize = 10.sp) }
                    )
                }
            }
        }
    }
}

@Composable
fun Dashboard(
    enabled: Boolean,
    toggle: () -> Unit,
    strength: Float,
    setStrength: (Float) -> Unit,
    stealth: Boolean,
    setStealth: (Boolean) -> Unit,
    onOverlayPermission: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TX7", color = Bright, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(" PRIVACY", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.Shield, null, tint = Bright)
        }

        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(20.dp)) {
            Column(
                Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("PRIVACY MODE", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.size(170.dp).background(
                        if (enabled) Color(0xFF21112F) else Color(0xFF15161A),
                        RoundedCornerShape(100.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Lock, null, tint = Bright, modifier = Modifier.size(52.dp))
                        Text(if (enabled) "ON" else "OFF", color = Bright, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                }
                TextButton(onClick = toggle) {
                    Text(if (enabled) "Tap to turn OFF" else "Tap to turn ON")
                }
            }
        }

        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row {
                    Text("PRIVACY STRENGTH", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("${(strength * 100).toInt()}%", color = Bright)
                }
                Slider(value = strength, onValueChange = setStrength)
            }
        }

        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VisibilityOff, null, tint = Bright)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("STEALTH MODE", fontWeight = FontWeight.Bold)
                    Text("Extra dark privacy overlay", color = Muted, fontSize = 12.sp)
                }
                Switch(checked = stealth, onCheckedChange = setStealth)
            }
        }

        Button(
            onClick = onOverlayPermission,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Security, null)
            Spacer(Modifier.width(8.dp))
            Text("ENABLE SCREEN OVERLAY")
        }

        Text(
            "The button opens Android's official 'Display over other apps' permission screen. This permission is required before TX7 can place a privacy overlay above other apps.",
            color = Muted,
            fontSize = 11.sp
        )
    }
}

@Composable
fun SimplePage(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(16.dp))
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ChevronRight, null, tint = Bright)
                Spacer(Modifier.width(12.dp))
                Text(subtitle, color = Muted)
            }
        }
    }
}
